library(ggplot2)
library(dplyr)
library(gt)
library(treemapify)
library(scales)
library(egg)
library(randomcoloR)
library(waffle)
library(formattable)
library(tidyr)

#bedziemy sie zastanawiali dla dla danej linii lotniczej, ile samolotw ja obsluguje
#uwaga jest taka, ze nie bedziemy tutaj rozwazac faktu, ze moga byc samoloty obslugiwane przez
#rozne linie lotnicze

vector<-c(2003:2008)

carriers_path<-file.path(".","dataverse_files", "carriers.csv")

carriers<-read.csv(carriers_path)

counter<-0

for (x in vector){
  our_string= paste(x,".csv.bz2",sep = "")
  file_path<-file.path(".","dataverse_files",our_string)
  data<-read.csv(file_path)
  data<-filter(data, data$Cancelled==0)
  data_from<-select(data, UniqueCarrier,Origin)
  data_from<-data %>% group_by(Origin) %>%summarize(!!(as.character(x)):=length(UniqueCarrier))
  data_from<-as.data.frame(data_from)
  if(counter==0){
    counter<-counter+1
    final_data_from<-data_from
  }else{
    final_data_from<-final_data_from %>% full_join(data_from, by = c("Origin"))
  }
}

#w jakich lotniskach liczba skąd startowali malala

#mozemy zrobic wykres (jakie firmy mialy)

final_data_from<-final_data_from %>%mutate(totalSum=rowSums(.[2:length(final_data_from)]))
final_data_from<-final_data_from[complete.cases(final_data_from),]
final_data_from<- final_data_from %>% arrange(desc(totalSum))

greatest20<-final_data_from[1:20,]
greatest20

#pokazemy 20 lotnisk, najczesciej odloty oraz 20 lotnisk najzadziej odloty
#inaczej wiemy juz z jakich lotnisk byly najczesciej przyloty, patrzymy jednak czy ta liczba na przestrzeni lat byla
#w miare stabilna to znaczy, w jaki sposob zmieniala sie dla danego lotniska zaleznosc rozpoczetych z niego lotow


#rozwazamy 20 lotnisk najczesciej odloty, na podstawie wykresu jestesmy w stanie ocenic, czy to lotnisko cieszy sie duzym powodzeniem
#czy firmy, ktore sa skuteczne(maja najwiecej odlotow z niego) na przestrzeni lat czy nic sie nie zmienilo
#badamy tutaj stabilnosc stad wykres zawiera linie laczace punkty dla odpowiednich przyporzadkowan

final_data_from_bs<-greatest20[,3:length(greatest20)-1]

final_data_from_bs

smallest_values<-apply(final_data_from_bs, 1, FUN = min)
biggest_values<-apply(final_data_from_bs, 1, FUN = max)

final_data_from_bs<- greatest20 %>% mutate(smallest_values,biggest_values)

final_data_from_bs<- final_data_from_bs %>% select(Origin, smallest_values, biggest_values)

fpart<-final_data_from_bs[,c(1,2)]
spart<-final_data_from_bs[,c(1,3)]

fpart
spart

first_plot<-ggplot(final_data_from_bs,aes(x=smallest_values,y=Origin))+geom_point()+geom_point(aes(x=biggest_values,y=Origin),colour="red")+
  geom_segment(aes(x = smallest_values, xend = biggest_values, y = Origin, yend = Origin), colour = "orange")+
  labs(y="Airports",x="Range in which planes departed from airports",
       title = "20 biggest airports from which planes took off and the amount of departures",
       subtitle = "Data hasa been considered from 2003 to 2008")
first_plot<-first_plot+theme(plot.subtitle = element_text(size=10))

first_plot

#sprawdzamy pozniej jaka jest roznica dla lotnisk firma, ktora ma najwiecej odlotow a ich najmniej
#to jest mamy dane lotnisko o najwiekszej liczbie odlotow i lotnisko o najmniejszej liczbie odlotow

#wzbudzenie emocji wsrod ogladajacych, pokazujemy ile odlotow rozni najbardziej polpularne i najmniej popularne lotnisko
#w tym aspekcie
departure_diff<- final_data_from[1,length(final_data_from)]-final_data_from[length(final_data_from),length(final_data_from)]

departure_diff

final_data_from_bs

#rozwazamy teraz loniska, z ktorych jest najmniej odlotow

final_data_from_rev<-final_data_from<- final_data_from %>% arrange(totalSum)
smallest20<-final_data_from_rev[1:20,]

final_data_from_bs_rev<-smallest20[,3:length(greatest20)-1]
final_data_from_bs_rev

#zamiast traktowac te wszystkie lotniska oddzielnie, potraktujmy je jako jedno i sprawdzmy czy zachodza jakies wlanosci
additional_counter<-0

final_data_from_bs_rev

looking_length<-length(final_data_from_bs_rev[[1]])

total_x_axes<-c()
total_y_axes<-c()

for(va in 1:length(final_data_from_bs_rev)){
  that_name<- as.integer(names(final_data_from_bs_rev)[va])
  y_axes<-final_data_from_bs_rev[,va]
  x_axes<-c()
  for(i in 1:looking_length){
    x_axes<-append(x_axes,that_name)
  }
  total_x_axes<-append(total_x_axes,x_axes)
  total_y_axes<-append(total_y_axes,y_axes)
}

super_data_frame<-data.frame(x=total_x_axes, y=total_y_axes)
super_data_frame

curve_property<-ggplot(super_data_frame, aes(x,y))+labs(x="Years",y="Amount of departures",
                                                        title="The curve of flights changes from the least popular airports")+geom_point()+geom_smooth(color="orange")

curve_property<-curve_property+theme(plot.title = element_text(size=12))

curve_property
