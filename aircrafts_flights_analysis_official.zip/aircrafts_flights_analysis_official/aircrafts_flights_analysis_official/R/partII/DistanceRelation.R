library(ggplot2)
library(dplyr)
library(gt)
library(treemapify)
library(scales)
library(egg)
library(randomcoloR)
library(waffle)
library(formattable)

#bedziemy sie zastanawiali, ktora linia lotnicza pokonuje najdluzsze trasy, czy laczy sie to tez z poprzednimi wykresami
#to znaczy wiemy jakie firmy wykonaly najwiecej lotow na przestrzeni lat, ale czy rowniez pokonuja one najdluszej trasy?

#czy pokonywanie dlugich tras mozna utozsamic z istnieniem implikacji (duzo lotow) => (pokonywanie dlugich dystansow)

vector<-c(2006:2008)

carriers_path<-file.path(".","dataverse_files", "carriers.csv")

carriers<-read.csv(carriers_path)

counter<-0
#bedziemy rozwazali tylko te loty, ktore nie zostaly odwolane

for (x in vector){
  our_string= paste(x,".csv.bz2",sep = "")
  file_path<-file.path(".","dataverse_files",our_string)
  data<-read.csv(file_path)
  data<-filter(data, data$Cancelled==0)
  data<-as.data.frame(data)
  data<- data %>% select(UniqueCarrier, Distance)
  if(counter==0){
    final_distance_data<-data
    counter<-counter+1
  }else{
    final_distance_data<-final_distance_data %>% inner_join(data, by = c("UniqueCarrier"))
  }
}
#bedziemy sprawdzali czy firmy w pewnym momencie zaczely pokonywac coraz krotsze czy coraz dluzsze dystansy
