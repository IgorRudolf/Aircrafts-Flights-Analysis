library(ggplot2)
library(dplyr)
library(gt)
library(treemapify)
library(scales)
library(egg)

install.packages("treemapify")
install.packages("egg")

vector<-c(2000:2008)

carriers_path<-file.path(".","dataverse_files", "carriers.csv")

carriers<-read.csv(carriers_path)

counter<-0

for (x in vector){
  our_string= paste(x,".csv.bz2",sep = "")
  file_path<-file.path(".","dataverse_files",our_string)
  data<-read.csv(file_path)
  data<-filter(data, data$Cancelled==0)
  data<-select(data, UniqueCarrier)
  #bedziemy rozwazali tylko te loty, ktore nie zostaly odwolane

  associate_data<- data %>% group_by(UniqueCarrier) %>% summarise(!!(as.character(x)):=length(UniqueCarrier))
  associate_data<-as.data.frame(associate_data)
  if(counter==0){
    final_associate_data<-associate_data
    counter<-counter+1
  }else{
    final_associate_data<-final_associate_data %>% full_join(associate_data, by = c("UniqueCarrier"))
  }

}
final_associate_data<-final_associate_data %>%mutate(totalSum=rowSums(.[2:length(final_associate_data)]))

#bedziemy chcieli pokazac, jakie firmy maja najwieksza dominacje na rynku(powiedzmy 5 przewoznikow lotniczych)

domination<-select(final_associate_data, UniqueCarrier, totalSum)
domination<-domination %>%arrange(desc(totalSum))
domination<-slice(domination,1:5)

domination<-domination %>% inner_join(carriers, by=c("UniqueCarrier"="Code"))

final_domination<-domination[,c(3,2)]
names(final_domination)[1]<-"Carrier"
names(final_domination)[2]<-"Flights"

final_domination<-as_tibble(final_domination)

gt_tbl<-gt(final_domination)

gt_tbl <-
  gt_tbl |>
  tab_header(
    title = "Carriers with the largest share",
    subtitle = "The top five largest are presented"
  )|>  tab_footnote(
    footnote = md("Only the data with **not cancelled** flights were considered. 2003-2008")
    )
)


gt_tbl
#mozemy pokazac udzial wszystkich firm w formie tabelki []

names(final_associate_data)[length(final_associate_data)]<-"totalSum"

names(final_associate_data)[length(final_associate_data)]<-"Flights_Amount"

all_into_square_data<- select(final_associate_data,  UniqueCarrier, Flights_Amount)

tree_fill<-ggplot(all_into_square_data, aes(area =  Flights_Amount, fill =  Flights_Amount, label = UniqueCarrier)) +
  geom_treemap() +
  geom_treemap_text(colour = "white",place = "centre",
                    size = 15)+ scale_fill_continuous(labels = scales::scientific)

tree_fill<-tree_fill+labs(title="Carriers and their share in marketplace",
                          subtitle = "Data has been considered from 2000 to 2008")

tree_fill<-tree_fill+theme(plot.subtitle = element_text(size=10))

tree_fill

#warto sie zastanwoic czy jak juz widzimy, kto jest rekinem biznesu to czy ich wejscie na rynek
#bylo dosc gwaltowne, to znaczy czy przewoznicy, ktorzy maja najwiecej lotow weszli na rynek gwaltownie
#i zaczeli go przyjowac czy byl to jednak proces stopniowy

grow_of_companies<-final_associate_data %>% arrange(desc(Flights_Amount)) %>% slice(1:4)
grow_of_companies<-grow_of_companies[,c(1:length(grow_of_companies)-1)]

#szukanie krzywej najlepszego dopasowania dla najbardziej skutecznych firm, sprawdzimy czy istnieje jakas zaleznosc
#moze ta krzywa w jakis sposob pomoze nam z wejsciem na rynek?

#zrobimy kazdy wykres oddzielnie dla tych czterech, pozniej pokazemy wszystkie na raz

name1<-grow_of_companies[1,1]
name2<-grow_of_companies[2,1]
name3<-grow_of_companies[3,1]
name4<-grow_of_companies[4,1]

val1<- unname(unlist(grow_of_companies[1,2:length(grow_of_companies)]))
val2<- unname(unlist(grow_of_companies[2,2:length(grow_of_companies)]))
val3<- unname(unlist(grow_of_companies[3,2:length(grow_of_companies)]))
val4<- unname(unlist(grow_of_companies[4,2:length(grow_of_companies)]))

df1<-data.frame(x=vector,y=val1)
df2<-data.frame(x=vector,y=val2)
df3<-data.frame(x=vector,y=val3)
df4<-data.frame(x=vector,y=val4)


integer_breaks <- function(n = 5, ...) {
  fxn <- function(x) {
    breaks <- floor(pretty(x, n, ...))
    names(breaks) <- attr(breaks, "labels")
    breaks
  }
  return(fxn)
}

text1<- paste("Change in the flights for the carrier ",name1,sep = "",collapse = "")
text2<- paste("Change in the flights for the carrier ",name2,sep = "",collapse = "")
text3<- paste("Change in the flights for the carrier ",name3,sep = "",collapse = "")
text4<- paste("Change in the flights for the carrier ",name4,sep = "",collapse = "")

g1 <- ggplot(df1, aes(x=vector,y=y,color=df1$x))+
  geom_point(colour="red",size=4)+scale_x_continuous(breaks = integer_breaks())

g1<-g1+geom_line(color="lightblue",linewidth=2)+labs(x="Years",y="Completed Flights",title=text1)

g1


g2<- ggplot(df2, aes(x=vector,y=y))+
  geom_point(colour="blue",size=4)+scale_x_continuous(breaks = integer_breaks())

g2<-g2+geom_line(color="lightblue",linewidth=2)+labs(x="Years",y="Completed Flights",title=text2)

g2

g3<- ggplot(df3, aes(x=vector,y=y))+
  geom_point(colour="green",size=4)+scale_x_continuous(breaks = integer_breaks())

g3<-g3+geom_line(color="lightblue",linewidth=2)+labs(x="Years",y="Completed Flights",title=text3)

g3

g4<- ggplot(df4, aes(x=vector,y=y))+
  geom_point(colour="orange",size=4)+scale_x_continuous(breaks = integer_breaks())

g4<-g4+geom_line(color="lightblue",linewidth=2)+labs(x="Years",y="Completed Flights",title=text4)

g4

gcombined<-ggarrange(g1, g2,g3,g4,ncol = 2,nrow = 2)

gcombined
#umiescmy teraz te wszystkie cztery wykresy


#bedziemy chcieli zweryfikowac czy jakas firma upadla

#dla firm, ktore maja najwiecej lotow(powiedzmy top 5) zastanowimy sie co robia dobrze a co zle

#potraktujmy te wszystkie firmy jako jedna i sprawdzmy jak sie zachowuja punkty na wykresie

x_combined_axes<-c()
y_combined_axes<-c()

x_combined_axes<-append(x_combined_axes, df1$x)
x_combined_axes<-append(x_combined_axes, df2$x)
x_combined_axes<-append(x_combined_axes,df3$x)
x_combined_axes<-append(x_combined_axes,df4$x)

y_combined_axes<-append(y_combined_axes, df1$y)
y_combined_axes<-append(y_combined_axes, df2$y)
y_combined_axes<-append(y_combined_axes, df3$y)
y_combined_axes<-append(y_combined_axes, df4$y)

combined_data_frame<- data.frame(x=x_combined_axes, y=y_combined_axes)

combined_plot<-ggplot(combined_data_frame, aes(x,y))+geom_point(colour="darkblue",size=2)+scale_x_continuous(breaks = integer_breaks())+
  labs(x="Years",y="Completed Flights",title = "Combined dependence of flights performed for 4 carriers with the biggest share in flights")+
  geom_smooth(color="red",size=1)+scale_y_continuous(labels = scales::scientific_format())

combined_plot
