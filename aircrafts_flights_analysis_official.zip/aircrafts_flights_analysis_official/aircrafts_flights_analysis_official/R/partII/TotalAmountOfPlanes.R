library(ggplot2)
library(dplyr)
library(gt)
library(treemapify)
library(scales)
library(egg)
library(randomcoloR)
library(waffle)
library(formattable)

#bedziemy sie zastanawiali dla dla danej linii lotniczej, ile samolotw ja obsluguje
#uwaga jest taka, ze nie bedziemy tutaj rozwazac faktu, ze moga byc samoloty obslugiwane przez
#rozne linie lotnicze

vector<-c(2000:2008)

carriers_path<-file.path(".","dataverse_files", "carriers.csv")

carriers<-read.csv(carriers_path)

counter<-0

for (x in vector){
  our_string= paste(x,".csv.bz2",sep = "")
  file_path<-file.path(".","dataverse_files",our_string)
  data<-read.csv(file_path)
  data<-filter(data, data$Cancelled==0)
  data<-select(data, UniqueCarrier,TailNum)
  data<-data %>% group_by(UniqueCarrier) %>%summarize(!!(as.character(x)):=length(UniqueCarrier))
  data<-as.data.frame(data)
  if(counter==0){
    counter<-counter+1
    final_planes_data<-data
  }else{
    final_planes_data<-final_planes_data %>% full_join(data, by = c("UniqueCarrier"))
  }
}
final_planes_data<-final_planes_data %>%mutate(totalSum=rowSums(.[2:length(final_planes_data)]))

#robimy teraz wykres, jakie firmy maja najwiecej samolotow, zestawiamy to z wykresem, ktora firma ma najwiecej
#lotow wykonanych lotow, czy sa to czynniki od siebie zalezne(zastanawiamy sie czy warunkiem koniecznym
#sukcesu firmy jest ilosc posiadanych przez nia samolotow)

#zestawiamy to z tym ile wszystkich lotow przypada na dany samolot tj: liczba wszystkich lotow/liczba samolotow

#sprawdzamy czy firmy, ktore wykonaly najwiecej lotow, mialy najwiecej samolotow

domination_planes<-select(final_planes_data, UniqueCarrier, totalSum)
#w niektorych wierszach dla firm jest NA, pominiemy takie firmy w naszych rozwazaniach bo nie mozemy za wiele
#o nich powiedziec

domination_planes<- filter(domination_planes, !is.na(domination_planes$totalSum))

all_planes<-sum(domination_planes[,c("totalSum")])

#zrobimy wykres, ktory bedzie nam mowil jak to wyglada w liczbach statystyka oraz w procentach

#wykres dla procentow

totalLength<-length(domination_planes[,1])
n<-totalLength

palette <- randomColor(n, hue = "red", luminosity = "light")

percentage_dominatnation_planes<-domination_planes %>% mutate(Percentage= totalSum/all_planes)

percentage_dominatnation_planes<-percentage_dominatnation_planes %>% arrange(desc(Percentage)) %>% slice(1:5)

percentage_dominatnation_planes_only<- percentage_dominatnation_planes[,c(1,3)]


#robimy teraz cos ciekawego, zakladamy, ze tylko te 5 firm tworzy 100% udzialow, zastanawiamy sie jak wyglada
#wtedy statystyka (patrzymy po prostu czy jest jakas przpasc miedzy tymi firmami, czy tez jej nie ma)

total_percentage <- sum(percentage_dominatnation_planes_only$Percentage)
percentage_dominatnation_planes_only$Percentage <- percentage_dominatnation_planes_only$Percentage / total_percentage

percentage_dominatnation_planes_only$Tiles <- round(percentage_dominatnation_planes_only$Percentage * 100)

df<-percentage_dominatnation_planes_only$Tiles
names(df)<-percentage_dominatnation_planes_only$UniqueCarrier

waffle(df, rows = 10, size = 0.5,
       colors = c("#F8766D", "#A3A500", "#00BF7D", "#00B0F6", "#E76BF3"),
       title = "Five companies only on market",
       xlab = "Percentage share of five companies having the biggest amount of planes 2000-2008")

#z wykresu widac, ze istnieje firma, ktora ma ich stosunkowo wiecej, jednak pozostale firmy sa do siebie w miare podobne


#bedziemy sprawdzali, ktora firma ma najwiecej samolotow, czy liczba samolotow wykorzystywanych
comparing_five_companies_percentage<-percentage_dominatnation_planes

comparing_five_companies_percentage$Percentage<-comparing_five_companies_percentage$Percentage*100

names(comparing_five_companies_percentage)[3]<-"Percentage_share"

comparing_five_companies_percentage

fort<-formattable(comparing_five_companies_percentage, align =c("l","c","c","c","c", "c", "c", "c", "r"),list(
  `UniqueCarrier` = formatter("span", style = ~ style(color = "grey",font.weight = "bold")),
    `totalSum`= color_bar("#00BF7D"),
    `Percentage_share`= color_bar("#A3A500")))

fort<-fort+ggtitle("Carriers with the")

print(fort)
cat('\n')

#jaka jest srednia wartosc Percentage_share dla wszystkich firm

average_percentage<-100/length(domination_planes[,1])

average_percentage
#warto powiedziec wlasnie o tym srednim procencie, np umiescic go w prezentacji



#przez firmy zawsze rosnie, czy dzieje sie moze tez cos innego z nimi

#sprawdzimy jaki procent wszystkich samolotow w naszych danych nalezy do najwiekszych firm

#warto sie tez zastanowic jaki jest sredni wspolczynnik dla wszystkich przewoznikow i jak bardzo sie
#rozni od tych firm z czolowki stawki
