library(dplyr)
library(ggplot2)
library(tidyr)
library(gganimate)
install.packages("gifski")
install.packages("av")
library(gifski)
library(av)
install.packages("timetk", "zoo", "datasets", "gganimate")
install.packages("zoo")
install.packages("timetk")
install.packages("datasets")
install.packages("gganimate")
library(zoo)
library(timetk)
library(datasets)
library(gganimate)
wektor <- c(2004:2008)
#Opóźnienie ze względu na pogodę(widzimy, że w okresie wakacyjnym i zimowym najczęściej pogoda wpływa na opóźnienia)
counter = 0
for (x in wektor){
  nazwa_pliku <- paste(x, ".csv.bz2", sep="")
  file_path <- file.path(".", "dataverse_files", nazwa_pliku)
  data <- read.csv(file_path)
  final <- data %>% select(Month, WeatherDelay) %>% na.omit %>% group_by(Month) %>% summarise(weatherDelay = sum(WeatherDelay))
  WeatherDelayInHrs <- final[,-1]/3600
  final <- cbind(final[,-2], WeatherDelayInHrs)
  if(counter == 0){
    final_delays_in_all_years <- final
    counter <- counter+1
  }else{
    final_delays_in_all_years <- merge(final_delays_in_all_years,final,by='Month', all=TRUE)
  }

}
final_delays_in_all_years <- df10
colnames(final_delays_in_all_years)[c(2:6)] <- c(2004:2008)
final_delays_in_all_years[is.na(final_delays_in_all_years)] <- 0
########
final_delays_in_all_years_pivoted <- pivot_longer(final_delays_in_all_years, cols=as.character(2004:2008), names_to = "Year")
colnames(final_delays_in_all_years_pivoted)[3] <- "WeatherDelayInHrs"
final_delays_in_all_years_pivoted
plot3 <- ggplot(final_delays_in_all_years_pivoted, mapping = aes(x = Month, y = WeatherDelayInHrs, color = Year, group = Year)) + geom_line() + scale_x_continuous(labels = function(x) round(x)) + ggtitle("Influence of weather on delays in individual months") +
  theme(plot.title = element_text(hjust = 0.5)) + labs(y="Weather Delay In Hours") + transition_reveal(Month)
g <- animate(plot3,nframes=144,fps=5)
########
########
