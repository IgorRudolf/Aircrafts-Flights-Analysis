install.packages("ggplot2")
library(ggplot2)
library(dplyr)
library(tidyr)
wektor <- c(2003:2008)
counter = 0
for (x in wektor){
  nazwa_pliku <- paste(x, ".csv.bz2", sep="")
  file_path <- file.path(".", "dataverse_files", nazwa_pliku)
  data <- read.csv(file_path)
  data <- filter(data, CarrierDelay!=" ", SummarisedDelay !=" ", WeatherDelay != " ", NASDelay != " ", SecurityDelay != "", LateAircraftDelay != " ")
  SummarisedDelay <- sum(data[25:29], na.rm = TRUE)
  CarrierDelay <- sum(data[25], na.rm = TRUE)/SummarisedDelay
  WeatherDelay <- sum(data[26], na.rm = TRUE)/SummarisedDelay
  NASDelay <- sum(data[27], na.rm = TRUE)/SummarisedDelay
  SecurityDelay <- sum(data[28], na.rm = TRUE)/SummarisedDelay
  LateAircraftDelay <- sum(data[29], na.rm = TRUE)/SummarisedDelay

  data_with_delays <- data.frame(Carrier = CarrierDelay, Weather = WeatherDelay, NAS = NASDelay,
                                 Security= SecurityDelay, LateAircraft = LateAircraftDelay)
  if(counter == 0){
    final_data_with_delays <- data_with_delays
    counter <- counter+1
  }else{
    final_data_with_delays <- final_data_with_delays %>% full_join(data_with_delays)
  }
}
final_data_with_delays$Year <- c(2003:2008)
final_data_with_delays
p <- gather(final_data_with_delays, key="variable", value = "ImpactOfFactorsInPercent", -Year)
bar <- ggplot(p, aes(x=Year, y=ImpactOfFactorsInPercent, fill = variable)) + geom_bar(stat="identity", position = "stack") + scale_x_continuous(labels = function(x) round(x)) + ggtitle("What causes flight delays \nand to what extent in %") + theme(plot.title = element_text(hjust = 0.5)) + labs(y="Summarized Delay In Minutes")
######
################################################################################################

#     TO     SAMO      ALE      NIE      PROCENTOWO     ######################
for (x in wektor){
  nazwa_pliku <- paste(x, ".csv.bz2", sep="")
  file_path <- file.path(".", "dataverse_files", nazwa_pliku)
  data <- read.csv(file_path)
  data <- filter(data, CarrierDelay!=" ", SummarisedDelay !=" ", WeatherDelay != " ", NASDelay != " ", SecurityDelay != "", LateAircraftDelay != " ")
  SummarisedDelay <- sum(data[25:29], na.rm = TRUE)
  CarrierDelay <- sum(data[25], na.rm = TRUE)
  WeatherDelay <- sum(data[26], na.rm = TRUE)
  NASDelay <- sum(data[27], na.rm = TRUE)
  SecurityDelay <- sum(data[28], na.rm = TRUE)
  LateAircraftDelay <- sum(data[29], na.rm = TRUE)

  data_with_delays <- data.frame(Carrier = CarrierDelay, Weather = WeatherDelay, NAS = NASDelay,
                                 Security= SecurityDelay, LateAircraft = LateAircraftDelay)
  if(counter == 0){
    final_data_with_delays <- data_with_delays
    counter <- counter+1
  }else{
    final_data_with_delays <- final_data_with_delays %>% full_join(data_with_delays)
  }
}
final_data_with_delays$Year <- c(2003:2008)
final_data_with_delays
p2 <- gather(final_data_with_delays, key="variable", value = "SummarizedDelayInMinutes", -Year)
bar2 <- ggplot(p2, aes(x=Year, y=SummarizedDelayInMinutes, fill = variable)) + geom_bar(stat="identity", position = "stack") + scale_x_continuous(labels = function(x) round(x)) + ggtitle("What causes flight delays \nand to what extent") + theme(plot.title = element_text(hjust = 0.5)) + labs(y="Summarized Delay In Minutes")












