install.packages("ggplot2")
library(ggplot2)
library(dplyr)
library(reshape)
#nie uwzgledniamy pogody, bo to już nie zależy od firmy
wektor <- c(2003:2008)
counter = 0
for (x in wektor){
  nazwa_pliku <- paste(x, ".csv.bz2", sep="")
  file_path <- file.path(".", "dataverse_files", nazwa_pliku)
  data <- read.csv(file_path)
  data_with_mostly_delayed_carriers <- as.data.frame(data[,c(9,25,26,27,28,29)]) %>% na.omit %>%
    group_by(UniqueCarrier) %>% summarise(TotalDelay = sum(CarrierDelay, NASDelay, SecurityDelay, LateAircraftDelay))
  data_with_mostly_delayed_carriers <- as.data.frame(data_with_mostly_delayed_carriers)
  if(counter == 0){
    final_data_with_mostly_delayed_carriers <- data_with_mostly_delayed_carriers
    counter <- counter+1
  }else{
    final_data_with_mostly_delayed_carriers <- merge(final_data_with_mostly_delayed_carriers,data_with_mostly_delayed_carriers,by='UniqueCarrier', all=TRUE)
  }
}
final_data_with_mostly_delayed_carriers <- final_data_with_mostly_delayed_carriers[,c(1:7)]
colnames(final_data_with_mostly_delayed_carriers)[2:7] <- c(2003:2008)
final_data_with_mostly_delayed_carriers <- final_data_with_mostly_delayed_carriers %>% na.omit
godziny <- final_data_with_mostly_delayed_carriers[,-1]/3600
df1 <- cbind(UniqueCarrier=final_data_with_mostly_delayed_carriers[,1], godziny)
OSTATECZNY <- df1
OSTATECZNY$col <- c(1:15)
rownames(OSTATECZNY) <- NULL

#wykres

install.packages("tidyr")
library("tidyr")
OSTATECZNY2 <- pivot_longer(OSTATECZNY, cols=as.character(2003:2008), names_to = "year")
colnames(OSTATECZNY2)[3] <- "Year"
colnames(OSTATECZNY2)[4] <- "DelayInHours"

#TO JEST OKEJ -----
plot1 <- ggplot(OSTATECZNY2, aes(Year, DelayInHours, color=UniqueCarrier, group=UniqueCarrier))+geom_line() + ggtitle("Total Delay (Without weather)\n(Data from years 2003-2008)") +
  theme(plot.title = element_text(hjust = 0.5)) + labs(y="Delay In Hours")

plot2 <- ggplot(OSTATECZNY2, aes(Year, DelayInHours, color=UniqueCarrier, group=UniqueCarrier))+geom_line()+facet_wrap(facets = vars(UniqueCarrier)) + ggtitle("Total Delay (Without weather)\n(Data from years 2003-2008)") +
  theme(plot.title = element_text(hjust = 0.5)) + labs(y="Delay In Hours")

# JAKIE SAMOLOTY MAJA NAJCZESCIEJ SPOZNIENIA ###################################################




#### opóźnienia firm na jeden lot #########################
wektor <- c(2003:2008)
counter <- 0
for(x in wektor){
nazwa_pliku <- paste(x, ".csv.bz2", sep="")
file_path <- file.path(".", "dataverse_files", nazwa_pliku)
data <- read.csv(file_path)
head(data)
data_with_mostly_delayed_carriers <- as.data.frame(data[,c(9,25,26,27,28,29)]) %>% na.omit %>%
  group_by(UniqueCarrier) %>% summarise(TotalDelay = sum(CarrierDelay, NASDelay, SecurityDelay, LateAircraftDelay))
data_with_mostly_delayed_carriers <- as.data.frame(data_with_mostly_delayed_carriers)
flights_occured <- data %>% group_by(UniqueCarrier) %>% summarize(FlightsOccured = length(UniqueCarrier))
flights_occured <- as.data.frame(flights_occured)
tabelka <- merge(data_with_mostly_delayed_carriers, flights_occured, by="UniqueCarrier")
tabelka$DelayPerFlight <- tabelka$TotalDelay/tabelka$FlightsOccured
tabelka <- tabelka[,-c(2,3)]
if(counter == 0){
  final_tabelka <- tabelka
  counter <- counter+1
}else{
  final_tabelka <- merge(final_tabelka,tabelka,by='UniqueCarrier', all=TRUE)
  }
}
colnames(final_tabelka)[c(2:7)] <- c(2003:2008)
final_tabelka <- final_tabelka %>% na.omit()
row.names(final_tabelka) <- NULL
final_tabelka$col <- c(1:15)
temp <- final_tabelka
final_tabelka_pivoted <- pivot_longer(final_tabelka, cols=as.character(2003:2008), names_to = "Year")
colnames(final_tabelka_pivoted)[4] <- "DelayInMinutesPerFlight"
#####
plot_tabelka1 <- ggplot(final_tabelka_pivoted, aes(Year, DelayInMinutesPerFlight, color=UniqueCarrier, group=UniqueCarrier))+geom_line() + ggtitle("Delay in minutes per flight in different years") + theme(plot.title = element_text(hjust = 0.5)) + labs(y="Delay In Minutes Per Flight")
#####
plot_tabelka2 <- ggplot(final_tabelka_pivoted, aes(Year,UniqueCarrier)) + geom_tile(aes(fill=DelayInMinutesPerFlight)) + scale_fill_gradient(low = "green", high = "black") + labs(y="Unique Carrier") + ggtitle("Delay in minutes per flight in different years") + theme(plot.title = element_text(hjust = 0.5))
