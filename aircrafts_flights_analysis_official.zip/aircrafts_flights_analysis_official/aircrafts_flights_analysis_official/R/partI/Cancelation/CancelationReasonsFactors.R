vector<-c(2007:2008)

for (x in vector){
  our_string= paste(x,".csv.bz2",sep = "")
  file_path<-file.path(".","dataverse_files",our_string)
  data<-read.csv(file_path)
  print(data$CancellationCode)
  considering_data<-table(data$CancellationCode)
  print(considering_data)
}

considering_data
total_counter<-considering_data[1]
A_counter<-considering_data[2]
B_counter<-considering_data[3]
C_counter<-considering_data[4]
D_counter<-considering_data[5]

#procentowy udzial odwolywania lodow poszczegolne czynniki na tle wszystkich lotow
A_counter/total_counter*100
B_counter/total_counter*100
C_counter/total_counter*100
D_counter/total_counter*100

#tworzymy bar plota
names(considering_data)[1]<-"all flights"
barplot(considering_data, main="Factors percentage of flights cancellation")


#procentowy udzial poszczegolnych odwolan tylko na tle odwolan
real_total_considering<-A_counter+B_counter+C_counter+D_counter
A<-A_counter/real_total_considering*100
B<-B_counter/real_total_considering*100
C<-C_counter/real_total_considering*100
D<-D_counter/real_total_considering*100

#tworzymy pie plota
slices<- c(A,B,C,D)
lbls<-c("A","B","C","D")
text<-paste(as.character(round(slices,digits = 4)),"%",sep = "")
pie(slices,labels = text,main = "Factors percentage of flights cancellation",col = rainbow(length(slices)))
legend("topleft", c("A","B","C","D"), cex = 0.8,
       fill = rainbow(length(slices)))

