library(ggplot2)
library(dplyr)
library(tidyr)
vector<-c(2000:2008)

counter<-0

for (x in vector){
  our_string= paste(x,".csv.bz2",sep = "")
  file_path<-file.path(".","dataverse_files",our_string)
  data<-read.csv(file_path)
  data<-filter(data, data$Cancelled==1)
  data<-select(data,Origin,Dest)
  data<-data[complete.cases(data),]
  data<- data %>% group_by(Origin, Dest) %>% summarise(!!(as.character(x)):=length(Origin))

  origin_read_data<- select(data,Origin)
  origin_read_data<-origin_read_data[complete.cases(origin_read_data),]
  origin_read_data<- origin_read_data %>%group_by(Origin) %>%summarise(!!(as.character(x)):=length(Origin))

  dest_read_data<-select(data,Dest)
  dest_read_data<-dest_read_data[complete.cases(dest_read_data),]
  dest_read_data<- dest_read_data %>%group_by(Dest) %>%summarise(!!(as.character(x)):=length(Dest))

  data<-as.data.frame(data)
  if(counter==0){
    final_data<-data
    origin_data<-origin_read_data
    dest_data<-dest_read_data
    counter<-counter+1
  }else{
    final_data<-final_data %>% inner_join(data, by = c("Origin","Dest"))
    origin_data<-origin_data %>%inner_join(origin_read_data,by=c("Origin"))
    dest_data<-dest_data  %>%inner_join(dest_read_data,by=c("Dest"))
  }
}
final_data<-final_data %>%mutate(totalSum=rowSums(.[3:length(final_data)]))

final_data<-final_data %>% arrange(desc(totalSum))


#pokazuje nam, z kad do kad najczesciej byly odwolywane loty
final_data

#na podstawie tego tworzymy wykres z kad do kad bylo najwiecej odwolan lotow na przestrzeni lat
names(final_data)

interesting_data<-final_data[1:20,c("Origin","Dest","totalSum")]


#wykresu tego uzywamy w celu budowania przypuszczen na temat jakie lotnisko jest tym problematycznym
ggp<-ggplot(interesting_data, aes(Origin,Dest))+geom_tile(aes(fill=totalSum))
ggp<-ggp+labs(title="Origin-Dest and amount of cancelled courses dependence",subtitle="Data has been considered between 2000-2008")
ggp<-ggp+theme(title = element_text(size = 10))

ggp

#zastanawiamy sie teraz z, ktorych lotnisk najczesciej byly odwolywane loty
origin_data<-as.data.frame(origin_data)
origin_data<-origin_data %>%mutate(totalSum=rowSums(.[2:length(origin_data)]))
origin_data<-origin_data %>%arrange(desc(totalSum))
origin_data<-slice(origin_data,1:20)
origin_data

origin_data_needed<-select(origin_data, Origin,totalSum )
origin_data_needed

blue_gradient <- colorRampPalette(c("lightblue", "darkblue"))

nggp<-ggplot(origin_data_needed,aes(x=Origin,y=totalSum,fill=Origin))+geom_bar(stat="identity")+
  scale_fill_manual(values = blue_gradient(length(unique(origin_data_needed$Origin))))+
  labs(y="Flights amount",title="Airports with the biggest amount of cancelled departures",
       subtitle = "Data has been considered between 2000-2008")
nggp

#zastanawiamy sie teraz jakie lotnisko jestli chodzi o przyloty bylo problematyczne
dest_data<-as.data.frame(dest_data)
dest_data<-dest_data %>%mutate(totalSum=rowSums(.[2:length(dest_data)]))
dest_data<-dest_data %>%arrange(desc(totalSum))
dest_data<-slice(dest_data,1:20)

dest_data_needed<-select(dest_data, Dest,totalSum)
dest_data_needed

orange_gradient<- colorRampPalette(c("lightblue", "purple"))

nggpo<-ggplot(dest_data_needed,aes(x=Dest,y=totalSum,fill=Dest))+geom_bar(stat="identity")+
  scale_fill_manual(values = orange_gradient(length(unique(origin_data_needed$Origin))))
nggpo<-nggpo+
  labs(y="Flights amount",title="Airports with the biggest amount of cancelled arrivals",
       subtitle = "Data has been considered between 2000-2008")

nggpo

#probujemy dostac takie lotniska, ktore maja problemy z lotami w obie strony, ile jest takich,
#ktore w jaka strone czesciej maja problemy

origin_data_needed
dest_data_needed

looking_for_similarities<- inner_join(origin_data_needed, dest_data_needed, by=c("Origin"="Dest"))
names(looking_for_similarities)

names(looking_for_similarities)[2]<-"Departures"
names(looking_for_similarities)[3]<-"Arrivals"

looking_for_similarities

data_long <- gather(looking_for_similarities, key = "Legend", value = "value", -Origin)

data_long

stacked_bars<-ggplot(data_long, aes(x = Origin, y = value, fill = Legend)) +
  geom_bar(stat = "identity", position = "stack")
stacked_bars<-stacked_bars+labs(x="Airport", y="Amount of cancellation",title=
                                  "Cancelled Arrivals and departures attitude",subtitle = "Data has been considered between 2000-2008")+
  scale_fill_manual(values=c('red', 'purple'))

stacked_bars

#jakkolwiek istnieje pewna mala roznica choc sie tak moze nie wydawac



#czy jakies lotniska odpadly z rozwazanych, jesli tak to jakie(dosc charakterystyczna cecha), zrobic przyrownanie
