library(dplyr)
library(ggplot2)
vector<-c(2007:2008)

for (x in vector){
  our_string= paste(x,".csv.bz2",sep = "")
  file_path<-file.path(".","dataverse_files",our_string)
  data<-read.csv(file_path)
  print(data$CancellationCode)
  considering_data<-table(data$CancellationCode)
  print(considering_data)

  data_with_cancelled_flights<-filter(data, data$Cancelled==1)

}
data_with_cancelled_flights
#wyznaczyc min, max, mediane, dzielimy dystans na pewne slupki
data
#powiazanie dystansu z odwolywaniem lotow

#wyznaczamy maxDist

distances<-data_with_cancelled_flights$Distance
max_cancelled_flight_distance<-max(distances,na.rm = TRUE)
max_cancelled_flight_distance

#wyznaczamy minDist
nonZeroDistances<-distances[distances>0]
min_cancelled_flight_distance<-min(nonZeroDistances,na.rm=TRUE)
min_cancelled_flight_distance

#wyznaczamy sredni dystans odwolanego lotu
total_distance_sum_of_cancelled_flights<-sum(nonZeroDistances,na.rm = TRUE)
without_na= nonZeroDistances[!is.na(nonZeroDistances)]
average_cancelled_flight_distance<-total_distance_sum_of_cancelled_flights/length(without_na)
average_cancelled_flight_distance

#wykres pokazujacy ile lotow jest odwolywanych w zaleznosci od dystansu jaki maja przebyc
hist(nonZeroDistances,breaks = 100, col='blue',border = ,xlab = "Distance planned to made",
     main = "Distance dependence on flights cancellation")
abline(v=average_cancelled_flight_distance,col="red",lwd=3)
legend("topright", c("Avg dist"), fill=c("red"))
text_to_be_added_max<-paste("max_dist: ",as.character(max_cancelled_flight_distance),sep = "")
text_to_be_added_min<-paste("min_dist:",as.character(min_cancelled_flight_distance),sep="")
text(x=4000,y=600,text_to_be_added_max)
text(x=4170,y=400,text_to_be_added_min)

#procentowy wykres pokazujacy ile procent odwolanych lotow stanowily dystanse mieszczace sie
#w wyznaczonym dystanie

divided_data<- table(cut_number(without_na, n = 10))
divided_data
