vector<-c(2007:2008)

cancelled_flights<-list(0,0,0,0,0,0,0,0,0,0,0,0)
cancelled_total_flights_due_to_days<-rep(0,31)

list_of_coefficiants<-list()

for (x in vector){
  our_string= paste(x,".csv.bz2",sep = "")
  file_path<-file.path(".","dataverse_files",our_string)
  data<-read.csv(file_path)
  logical_vars<-data$Cancelled==1
  season_data<-data[logical_vars, c("Month")]
  day_data<-data[logical_vars,c("DayofMonth")]
  season_final_data<-table(season_data)
  day_final_data<-table(day_data)
  for(i in 1:12){
    if(!is.na(season_final_data[i])){
      cancelled_flights[[i]]<-cancelled_flights[[i]]+season_final_data[i]
    }
  }
  for(i in 1:31){
    if(!is.na(day_final_data[i])){
      cancelled_total_flights_due_to_days[i]<-cancelled_total_flights_due_to_days[i]+day_final_data[i]
    }
  }

  totalConsideringSum= sum(season_final_data)
  percents<-season_final_data/totalConsideringSum*100
  list_of_coefficiants<-append(list_of_coefficiants,percents)
}
cancelled_flights<-unlist(cancelled_flights)
#sprawdzamy na przestrzeni lat w jakim miesiacu odwolano ile lotow(wykres słupkowy)
barplot(cancelled_flights,main="Cancelling dependence on months")

#dane ta zestawiamy z procentowym udzialem poszczegolnych miesiecy(pie plot)

total_amount<-sum(cancelled_flights)
percentage_values<- cancelled_flights/total_amount*100
slices<-percentage_values
lbls<-c("1","2","3","4","5","6","7","8","9","10","11","12")
text<-paste(as.character(round(slices,digits = 4)),"%",sep = "")
pie(slices,labels = text,main = "Month percentage of flights cancellation",col = rainbow(length(slices)))
#postarac sie jakos zrobic bardziej czytelny ten wykres
legend("bottomleft",
       c("Jauary","February","March","April","May","June","July","August","September","October","November","December")
       , cex = 0.8,
       fill = rainbow(length(slices)))

#sprawdzamy teraz czy dla lat dla poszczegolnych miesiecy dla poszczegolnych lat ten wykres malal
#(zwykly plot)

#ten wykres mówi mi, ze ze wszystkich odwolywan w danym roku np pewien procent wszystkich odwolywan
#stanowily tylko odwolania w danym miesiacu(upewnic sie czy jest to dobrze interpetowane)


#tworzymy pomocniczy data frame
x_axes<-2007:2008
x_axes
our_data_frame
#tworzymy ploty:
vector_of_coefficiants<-unlist(list_of_coefficiants)
vector_of_coefficiants

for(val in list_of_coefficiants){
  print(val)
}


vector_of_coefficiants[10]
for(month in 1:12){
  counter=0
  condition=TRUE
  value_vector<-c()
  while(condition){
    our_num= month+12*counter
    if(our_num>length(list_of_coefficiants)){
      condition<-FALSE
    }else{
      year_month_info= list_of_coefficiants[[our_num]]
      value_vector<-c(value_vector,year_month_info)
    }
    counter<-counter+1
  }
  print(value_vector)
  #mamy na tym etapie wektor z naszymi wartosciami
  y_axes<-value_vector
  if(month==1){
    plot(x_axes,y_axes[1:length(x_axes)],type = "b",xlab = "Lata",ylab = "Procent odwolywan lotow")
  }else{
    lines(x_axes,y_axes[1:length(x_axes)],type="b",col=colors()[month*30])
  }
}
length(list_of_coefficiants)
as.numeric(list_of_coefficiants[13])
typeof(list_of_coefficiants[[13]])


#sprawdzamy w jaki sposob dzien miesiaca wplywa na odwolywania lotow(czy ma to tak duze znaczenie?)
#zwykle zestawienie w postaci wykresu czyli z ilu wszystkich odwolanych lotow ile bylo danego dnia miesiaca
#(bardziej to mozna traktowac w formie jakiejs ciekawostki)
cancelled_total_flights_due_to_days<-unlist(cancelled_total_flights_due_to_days)
barplot(cancelled_total_flights_due_to_days,main="Flights cancelling dependence on days",col = rainbow(length(cancelled_total_flights_due_to_days)))
