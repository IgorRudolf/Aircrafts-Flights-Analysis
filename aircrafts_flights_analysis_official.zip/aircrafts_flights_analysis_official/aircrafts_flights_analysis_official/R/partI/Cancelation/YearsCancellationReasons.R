library(dplyr)
library(ggplot2)
#install.packages("tidyr")
library(splines)
vector<-c(2000:2008)

counter<-0

setwd("C:/RProgramming/aircrafts_flights_analysis")

path_to_plane_data<- file.path(".","dataverse_files", "plane-data.csv")
plane_data<-read.csv(path_to_plane_data)
plane_data<-select(plane_data,tailnum, year)
typeof(plane_data[plane_data$tailnum=="N10156",])


for (x in vector){
  our_string= paste(x,".csv.bz2",sep = "")
  file_path<-file.path(".","dataverse_files",our_string)
  data<-read.csv(file_path)
  data<-filter(data,data$Cancelled==1 & !is.na(data$TailNum) & data$TailNum!="")
  text<-as.character(x)
  cancellation_data<-data %>% group_by(TailNum) %>% summarise(!!(text):=length(TailNum))
  cancellation_data<-as.data.frame(cancellation_data)
  if(counter==0){
    planes_num_cancellation_years<-cancellation_data
    counter<-counter+1
  }else{
    planes_num_cancellation_years<- planes_num_cancellation_years %>% full_join(cancellation_data, by = c("TailNum"))
  }
}

planes_num_cancellation_years

planes_num_cancellation_years<-planes_num_cancellation_years[planes_num_cancellation_years$TailNum!=0 &
                                                               planes_num_cancellation_years$TailNum!="0"
                                                             & planes_num_cancellation_years$TailNum!="000000",]



# planes_num_cancellation_years<-planes_num_cancellation_years %>%
#   mutate(totalCancellations=rowSums(.[2:length(planes_num_cancellation_years)]), replace() )

planes_num_cancellation_years<-replace(planes_num_cancellation_years, is.na(planes_num_cancellation_years), 0)

#planes_num_cancellation_years<-planes_num_cancellation_years[complete.cases(planes_num_cancellation_years),]

planes_num_cancellation_years


total_sum_of_planes<-rowSums(planes_num_cancellation_years[2:length(planes_num_cancellation_years)],na.rm = TRUE)
data_frame_total_sum_of_planes<-data.frame(totalSum= total_sum_of_planes)

planes_num_cancellation_years<-planes_num_cancellation_years %>% mutate(data_frame_total_sum_of_planes)

planes_num_cancellation_years<-planes_num_cancellation_years[3:length(planes_num_cancellation_years[[1]]),]


planes_num_cancellation_years<- planes_num_cancellation_years %>% arrange(desc(totalSum))

planes_num_cancellation_years

years_vector<-c()

for(row in 1:length(planes_num_cancellation_years[[1]])){
  considered_row<-planes_num_cancellation_years[row,]
  considered_tailnum<-as.character(considered_row[1])
  considered_year<-plane_data[plane_data$tailnum==considered_tailnum,][2]
  years_vector<-c(years_vector,considered_year)
}

planes_num_cancellation_years

#bierzemy te samoloty, ktore maja najwiecej odwolan lotow na przestrzeni lat, np 19 i z nich patrzmy jak
#wiek samolotu jego wplywal na odwolywania lotow



cancellation_data
#sprawdzamy czy wiek samolotu wplywa na jego odwolania
plane_data<-select(plane_data,tailnum, year)

#bierzemy dane z tabelki o samolotach

path_to_plane_data
plane_data<-select(plane_data,tailnum, year)
plane_data<-filter(plane_data,plane_data$year!="")
plane_data<-filter(plane_data,plane_data$year!="None")
names(plane_data)[1]<-"TailNum"

names(plane_data)

planes_num_cancellation_years<-planes_num_cancellation_years[complete.cases(planes_num_cancellation_years),]

planes_num_cancellation_years<-planes_num_cancellation_years[3:length(planes_num_cancellation_years[[1]]),]

planes_num_cancellation_years

plane_data

planes_with_cancellations_and_years_second<- merge(planes_num_cancellation_years, plane_data, by = "TailNum")

planes_with_cancellations_and_years_second

planes_with_cancellations_and_years_second<-filter(planes_num_cancellation_years, TailNum!=0)
planes_with_cancellations_and_years_second<-filter(planes_with_cancellations_and_years_second, TailNum!="000000")

planes_with_cancellations_and_years_second<-planes_with_cancellations_and_years_second %>% arrange(desc(totalSum))

planes_with_cancellations_and_years_second

seeking<-planes_with_cancellations_and_years_second[3:length(planes_with_cancellations_and_years_second[[1]]),]

seeking


planes_with_cancellations_and_years_second<-seeking

planes_with_cancellations_and_years_second

looking_planes_num_cancellation_years<-planes_with_cancellations_and_years_second

looking_planes_num_cancellation_years<-looking_planes_num_cancellation_years[,1:length(looking_planes_num_cancellation_years)-1]

looking_planes_num_cancellation_years

planes_with_cancellations_and_years_second


#bierzemy dwadziescia samolotow, ktore mialy najwiecej odwolywan lotow

planes_with_cancellations_and_years_second_top<-planes_with_cancellations_and_years_second[1:20,]

rownames(planes_with_cancellations_and_years_second_top)<-NULL

planes_with_cancellations_and_years_second_top

library(tidyr)

da<-pivot_longer(planes_with_cancellations_and_years_second_top, cols = as.character(2000:2008),names_to = "year")
da

cancellation_planes<-ggplot(da, aes(year,value,color=TailNum, group=TailNum))+geom_point()+ geom_point(size=4)

cancellation_planes<-cancellation_planes+labs(y="Amount of cancellation",title="Cancellation dependence for plane and its age")

cancellation_planes


#robimy teraz mapke ciepla, patrzymy ile jest odwolan lotow, dla samolotow
#wyprodukowanych w poszczegolnych rocznikach

#dodamy najpierw rok z ktorego jest poszczegolny samolot

names(plane_data)

plane_data


looking_year_data

looking_year_data<-plane_data

looking_year_data<-filter(looking_year_data, year!="")
looking_year_data<-filter(looking_year_data,year!="None")
looking_year_data<-filter(looking_year_data,TailNum!="")
looking_year_data<-arrange(looking_year_data, totalSum)

looking_year_data


planes_num_cancellation_years

planes_num_cancellation_years<-inner_join(planes_num_cancellation_years, looking_year_data,by=c("TailNum"))

planes_num_cancellation_years<-planes_num_cancellation_years %>% arrange(desc(totalSum))
planes_num_cancellation_years<-slice(planes_num_cancellation_years,1:10)

planes_num_cancellation_years_additional<-as.data.frame(da)

planes_num_cancellation_years_additional

planes_num_cancellation_years_additional<-looking_year_data %>% group_by(year) %>%summarise(cons=sum(totalSum))

planes_num_cancellation_years_additional<-planes_num_cancellation_years_additional[,c(2,3)]

planes_num_cancellation_years_additional

grouped_planes<-planes_num_cancellation_years_additional %>% group_by(year)%>%summarize(len=sum(totalSum))

grouped_planes

looking_year_data

planes_num_cancellation_years

planes_num_cancellation_years<-planes_num_cancellation_years[3:length(planes_num_cancellation_years[[1]]),]

planes_num_cancellation_years

dt<-planes_with_cancellations_and_years_second %>% group_by(year) %>% summarise(sek=sum(totalSum))

dt<-as.data.frame(dt)

dt

planes_with_cancellations_and_years_second

dt<-as.data.frame(dt)
looking_year_data<-looking_year_data %>% group_by(year) %>% summarise(totalAmount= length(year))

looking_year_data

xd
dt<-dt[2:length(dt[[1]]),]

dt<-xd

dt['year']<-as.integer(dt$year)
dt['sek']<-as.integer(dt$sek)

dt<-dt[2:length(dt[[1]]),]
rownames(dt)<-NULL

dt<-dt[1:41,]

dt<-dt[2:41,]

dt

df<-dt
#samoloty, ktory powstaly w danym roku i ile odwolan lotow mialy do tej pory, weryfikacja hipotezy
#czy im jest starszy samolot tym ma wiecej odwolywan

median_value <- median(df$sek)

median_value

p<-ggplot(df, aes(x=year, y=sek, color=year)) +
  geom_bar(stat="identity", fill="white")+scale_fill_brewer(palette="Blues")+geom_hline(aes(yintercept = median_value, linetype = "Median"), color = "red") +
  scale_linetype_manual(values = c("Median" = "dashed"), guide = guide_legend()) +
  labs(linetype = "Line Type",x="Year",y="Amount of cancelled flights", title=
         "Relation between year plane and its cancellation")
p
