library(dplyr)
library(ggplot2)

vector<-c(2005:2008)

counter<-0
for (x in vector){
  our_string= paste(x,".csv.bz2",sep = "")
  file_path<-file.path(".","dataverse_files",our_string)
  data<-read.csv(file_path)
  carrier_data<-filter(data,!is.na(data$UniqueCarrier)& data$UniqueCarrier!="WN" & data$Cancelled==1)

  textToSet<-as.character(x)

  carrier_data<- carrier_data %>% group_by(UniqueCarrier) %>% summarise(!!(textToSet):=length(UniqueCarrier))
  carrier_data<-as.data.frame(carrier_data)

  if(counter==0){
    final_all_years_cancellations_by_company<-carrier_data
    counter<-counter+1
  }
  else{
    final_all_years_cancellations_by_company<- final_all_years_cancellations_by_company %>%
      full_join(carrier_data, by= c("UniqueCarrier"))
  }
}
final_all_years_cancellations_by_company


#chcemy wiedziec jaka firma miala najwiecej odwolanych lotow
#jaka firma miala najmniej odwolanych lotow

#w zaleznosci of firmy, ktora miala najwiecej odwolanych lotow bedziemy zwiekszali odpowiednio wspolczynnik
#intensywnosci zamalowan

#rozwazamy tylko te dane, ktore maja podanego przewoznika

#bedziemy sie zastanawiali czy jest to powiazane z iloscia posiadanych samolotow

?full_join

names(final_all_years_cancellations_by_company)
as.character("2008")


final_all_years_cancellations_by_company

#mozna teraz zrobic wykres odwolan lotow w zaleznosci od lat dla poszczegolnych firm(kazda firma innym kolorem)

#patrzymy ile bylo lacznie odwolan lotow na przestrzeni lat

totalSumByCarrierData<-final_all_years_cancellations_by_company %>% mutate(totalSum=
rowSums(.[2:length(final_all_years_cancellations_by_company)])) %>% select(UniqueCarrier, totalSum)

totalSumByCarrierData<-totalSumByCarrierData %>% arrange(totalSum)
totalSumByCarrierData<-totalSumByCarrierData[complete.cases(totalSumByCarrierData),]

totalSumByCarrierData


n_colors <- length(unique(totalSumByCarrierData$UniqueCarrier))


ggplotA<-ggplot(totalSumByCarrierData, aes(x=UniqueCarrier, y=totalSum)) +
  geom_bar(stat = "identity", width=0.2)+scale_fill_gradientn(colors = terrain.colors(n_colors))+scale_y_continuous(labels = scales::scientific_format())+
  labs(title="Amount of cancellation flights per carrier",subtitle = "Data has been considered from 2005 to 2008",y="Amount of flight cancellation")

ggplotA


firmaZNajmniejszaIlosciaOdwolanychLotow<-totalSumByCarrierData[[1]][1]
firmaZNajmniejszaIlosciaOdwolanychLotow

firmaZNajwiekszaIlosciaOdwolanychLotow<-totalSumByCarrierData[[1]][length(totalSumByCarrierData[[2]])]
firmaZNajwiekszaIlosciaOdwolanychLotow

?barplot
barplot(totalSumByCarrierData$totalSum, names.arg = totalSumByCarrierData$UniqueCarrier)

#wykres pokazujacy w jaki sposob malala lub rosla ilosc odwolywan lotow dla poszczegolnych firm

#uzyjemy nastepujacego wykresu
#final_all_years_cancellations_by_company

that_length<-length(final_all_years_cancellations_by_company[[1]])
typeof(unlist(final_all_years_cancellations_by_company[1,][2:3]))
unname(unlist(final_all_years_cancellations_by_company[1,][2:3]))
final_all_years_cancellations_by_company
that_length


nameOfColumn<-final_all_years_cancellations_by_company[[1]]
nameOfColumn

data_with_total_sum<-final_all_years_cancellations_by_company %>%
  mutate(totalSum=
           rowSums(.[2:length(final_all_years_cancellations_by_company)]))

#sprawdzamy jak zmienila sie liczba opoznienien dla 10 firm, ktore mialy najwiecej opoznien
#sprawdzamy jak zmienila sie liczba opoznien dla 10 firm, ktore mialy najmniej opoznien


data_with_total_sum

data_with_total_sum<- data_with_total_sum %>% arrange(desc(data_with_total_sum$totalSum))

data_with_total_sum<-data_with_total_sum[1:10,1:(length(data_with_total_sum)-1)]
data_with_total_sum


x_axes<-vector
second_counter<-0
for(element in 1:10){
  vectorData<-data_with_total_sum[element,]
  companyName<-vectorData[1]
  y_axes<-unname(unlist(vectorData[2:length(vectorData)]))
  if(second_counter==0){
    plot(x_axes,y_axes)
    second_counter<-second_counter+1
  }else{
    lines(x_axes,y_axes)
  }
}
takingElement

#zrobic teraz podobny wykres dla firm, ktore mialy najmniej odwolan lotow(czy dalej sa w tym dobre)


final_all_years_cancellations_by_company

second_data_with_total_sum<-final_all_years_cancellations_by_company %>%
  mutate(totalSum=
           rowSums(.[2:length(final_all_years_cancellations_by_company)]))

reversed_data_with_total_sum<- second_data_with_total_sum %>% arrange(second_data_with_total_sum$totalSum)

reversed_data_with_total_sum<-reversed_data_with_total_sum[1:10,1:(length(reversed_data_with_total_sum)-1)]

x_axes<-vector

new_second_counter<-0

reversed_data_with_total_sum

for(element in 1:10){
  vectorData<-reversed_data_with_total_sum[element,]
  companyName<-vectorData[1]
  y_axes<-unname(unlist(vectorData[2:length(vectorData)]))
  if(new_second_counter==0){
    plot(x_axes,y_axes)
    new_second_counter<-second_counter+1
  }else{
    lines(x_axes,y_axes)
  }
}




