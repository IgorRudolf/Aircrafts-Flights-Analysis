loty1987<-read.csv("C:/RProgramming/aircrafts_flights_analysis/dataverse_files/2006.csv.bz2")

info<-read.csv("C:/RProgramming/aircrafts_flights_analysis/dataverse_files/variable-descriptions.csv")

head(loty1987)

another_info<-read.csv("C:/RProgramming/aircrafts_flights_analysis/dataverse_files/plane-data.csv")


list.files("C:/RProgramming/aircrafts_flights_analysis/dataverse_files")

data<-loty1987
data[data$Cancelled==1,]
info

data

another_info

getwd()
unique(another_info$manufacturer)


library(ggplot2)

# Create a sample data frame
data <- data.frame(
  category = c("A", "A", "B", "B", "C", "C"),
  group = c("Group 1", "Group 2", "Group 1", "Group 2", "Group 1", "Group 2"),
  value = c(10, 15, 8, 12, 5, 20)
)

data

# Create the stacked bar plot
ggplot(data, aes(x = category, y = value, fill = group)) +
  geom_bar(stat = "identity", position = "stack")
